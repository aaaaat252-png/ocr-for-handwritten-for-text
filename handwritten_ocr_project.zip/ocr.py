from PIL import Image
import torch
from transformers import TrOCRProcessor, VisionEncoderDecoderModel


class HandwritingOCR:
    MODEL_NAME = "microsoft/trocr-base-handwritten"

    def __init__(self):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.processor = TrOCRProcessor.from_pretrained(self.MODEL_NAME)
        self.model = VisionEncoderDecoderModel.from_pretrained(
            self.MODEL_NAME
        ).to(self.device)
        self.model.eval()

    def recognize(self, image: Image.Image) -> str:
        pixels = self.processor(
            images=image.convert("RGB"),
            return_tensors="pt",
        ).pixel_values.to(self.device)

        with torch.no_grad():
            ids = self.model.generate(
                pixels,
                max_new_tokens=256,
                num_beams=4,
            )

        return self.processor.batch_decode(
            ids,
            skip_special_tokens=True,
        )[0].strip()
