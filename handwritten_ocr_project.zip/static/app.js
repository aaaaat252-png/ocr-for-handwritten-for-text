const file=document.getElementById("file");
const preview=document.getElementById("preview");
const run=document.getElementById("run");
const result=document.getElementById("result");
const status=document.getElementById("status");
const history=document.getElementById("history");

file.onchange=()=>{
  if(file.files[0]){
    preview.src=URL.createObjectURL(file.files[0]);
    preview.hidden=false;
  }
};

run.onclick=async()=>{
  if(!file.files[0]){status.textContent="Choose an image first.";return;}
  const fd=new FormData();
  fd.append("image",file.files[0]);
  run.disabled=true;
  status.textContent="Recognizing handwriting...";
  try{
    const r=await fetch("/api/ocr",{method:"POST",body:fd});
    const d=await r.json();
    if(!r.ok) throw Error(d.error);
    result.value=d.text;
    status.textContent="Recognition complete.";
    loadHistory();
  }catch(e){status.textContent=e.message}
  finally{run.disabled=false}
};

document.getElementById("copy").onclick=async()=>{
  await navigator.clipboard.writeText(result.value);
  status.textContent="Text copied.";
};

document.getElementById("pdf").onclick=async()=>{
  if(!result.value.trim()) return;
  const r=await fetch("/api/export/pdf",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({text:result.value})
  });
  const b=await r.blob();
  const u=URL.createObjectURL(b);
  const a=document.createElement("a");
  a.href=u;a.download="handwritten_ocr.pdf";a.click();
  URL.revokeObjectURL(u);
};

async function loadHistory(){
  const r=await fetch("/api/history");
  const items=await r.json();
  history.innerHTML=items.length
    ?items.map(x=>`<div class="item"><div><strong>${esc(x.filename||"Image")}</strong><div class="muted">${esc(x.created_at)}</div><div class="history-text">${esc(x.recognized_text)}</div></div><button onclick="del(${x.id})">Delete</button></div>`).join("")
    :'<p class="muted">No OCR results yet.</p>';
}

async function del(id){
  await fetch("/api/history/"+id,{method:"DELETE"});
  loadHistory();
}

function esc(s){
  return String(s).replaceAll("&","&amp;").replaceAll("<","&lt;")
    .replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");
}
loadHistory();
