# Handwritten Text OCR Studio

A complete handwritten OCR web application using Python, Flask, PyTorch, OpenCV, SQLite, ReportLab and Microsoft's TrOCR handwritten model.

## Features
- Handwritten image upload and preview
- OpenCV preprocessing
- TrOCR recognition
- Editable/copyable output
- PDF export
- SQLite OCR history
- Delete history records
- Automatic CUDA use when available

## Installation

Python 3.10+ is recommended.

Windows:
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

Linux/macOS:
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Run

```bash
python app.py
```

Open http://127.0.0.1:5000

The first run downloads the TrOCR model.

## Architecture

Image upload -> OpenCV preprocessing -> TrOCR -> editable text -> SQLite history / PDF.

## Accuracy

The base model works best on clear handwritten line images. Full-page notes should ideally be segmented into text lines before OCR.

## Future enhancements

- Full-page line segmentation
- User authentication
- Per-user OCR history
- Confidence scoring
- Multi-language models
- Custom dataset and TrOCR fine-tuning
- DOCX export
- Cloud deployment
