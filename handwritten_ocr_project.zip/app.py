import io
import sqlite3
from datetime import datetime
from pathlib import Path

from flask import Flask, jsonify, render_template, request, send_file
from PIL import Image
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

from ocr import HandwritingOCR
from preprocessing import preprocess_image

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "ocr_history.db"

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024
ocr = HandwritingOCR()


def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS history ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "filename TEXT, recognized_text TEXT NOT NULL,"
            "created_at TEXT NOT NULL)"
        )
        conn.commit()


@app.route("/")
def index():
    return render_template("index.html")


@app.post("/api/ocr")
def recognize():
    if "image" not in request.files:
        return jsonify(error="No image uploaded."), 400
    uploaded = request.files["image"]
    if not uploaded.filename:
        return jsonify(error="Please choose an image."), 400

    try:
        image = Image.open(uploaded.stream).convert("RGB")
        text = ocr.recognize(preprocess_image(image))

        with sqlite3.connect(DB_PATH) as conn:
            cur = conn.execute(
                "INSERT INTO history(filename, recognized_text, created_at) VALUES (?, ?, ?)",
                (uploaded.filename, text, datetime.now().isoformat(timespec="seconds")),
            )
            conn.commit()
            record_id = cur.lastrowid

        return jsonify(id=record_id, filename=uploaded.filename, text=text)
    except Exception as exc:
        return jsonify(error=str(exc)), 500


@app.get("/api/history")
def history():
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT * FROM history ORDER BY id DESC LIMIT 50"
        ).fetchall()
    return jsonify([dict(row) for row in rows])


@app.delete("/api/history/<int:record_id>")
def delete_history(record_id):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("DELETE FROM history WHERE id = ?", (record_id,))
        conn.commit()
    return jsonify(ok=True)


@app.post("/api/export/pdf")
def export_pdf():
    data = request.get_json(silent=True) or {}
    text = data.get("text", "").strip()
    if not text:
        return jsonify(error="There is no text to export."), 400

    buffer = io.BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4
    x, y = 50, height - 55
    pdf.setTitle("Handwritten OCR Result")
    pdf.setFont("Helvetica", 11)

    for paragraph in text.splitlines() or [""]:
        line = ""
        for word in paragraph.split():
            candidate = (line + " " + word).strip()
            if pdf.stringWidth(candidate, "Helvetica", 11) > width - 100:
                pdf.drawString(x, y, line)
                y -= 16
                line = word
                if y < 55:
                    pdf.showPage()
                    pdf.setFont("Helvetica", 11)
                    y = height - 55
            else:
                line = candidate
        pdf.drawString(x, y, line)
        y -= 16
        if y < 55:
            pdf.showPage()
            pdf.setFont("Helvetica", 11)
            y = height - 55

    pdf.save()
    buffer.seek(0)
    return send_file(
        buffer,
        mimetype="application/pdf",
        as_attachment=True,
        download_name="handwritten_ocr.pdf",
    )


init_db()

if __name__ == "__main__":
    app.run(debug=True)
