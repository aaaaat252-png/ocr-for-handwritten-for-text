"""
inference/segmentation.py
==========================
Splits a preprocessed binary image (text = white, background = black)
into lines, then words, then individual character glyphs, using
projection profiles and contour analysis. This is what lets a
per-character classifier operate on full lines/words instead of only
pre-cropped single letters.
"""

from typing import List, NamedTuple, Tuple

import cv2
import numpy as np

import config
from errors import SegmentationError, EmptyImageError


class BoundingBox(NamedTuple):
    x: int
    y: int
    w: int
    h: int


def _projection_ranges(profile: np.ndarray, min_gap: int = 1) -> List[Tuple[int, int]]:
    """Given a 1D projection profile, return (start, end) index ranges of
    contiguous non-zero runs, merging runs separated by gaps smaller than
    `min_gap`."""
    nonzero = profile > 0
    ranges = []
    start = None
    gap = 0
    for i, active in enumerate(nonzero):
        if active:
            if start is None:
                start = i
            gap = 0
        else:
            if start is not None:
                gap += 1
                if gap > min_gap:
                    ranges.append((start, i - gap))
                    start = None
                    gap = 0
    if start is not None:
        ranges.append((start, len(nonzero) - 1))
    return ranges


def segment_lines(binary_image: np.ndarray) -> List[np.ndarray]:
    """
    Split a full-page/paragraph binary image into individual text-line
    images using the horizontal projection profile (row-wise sum of
    foreground pixels).
    """
    if binary_image is None or binary_image.size == 0:
        raise EmptyImageError("Cannot segment lines from an empty image.")

    row_profile = np.sum(binary_image > 0, axis=1)
    ranges = _projection_ranges(row_profile, min_gap=1)

    lines = []
    for (y0, y1) in ranges:
        h = y1 - y0
        if h < config.MIN_CHAR_DIM:
            continue
        lines.append(binary_image[y0:y1 + 1, :])

    if not lines:
        raise SegmentationError(
            "No text lines detected in image (no horizontal foreground bands found)."
        )
    return lines


def segment_words(line_image: np.ndarray) -> List[np.ndarray]:
    """
    Split a single text-line image into word images using the vertical
    projection profile, treating gaps wider than a threshold (relative to
    line height) as word boundaries.
    """
    if line_image is None or line_image.size == 0:
        raise EmptyImageError("Cannot segment words from an empty line image.")

    col_profile = np.sum(line_image > 0, axis=0)
    line_h = line_image.shape[0]
    min_gap = max(1, int(line_h / config.WORD_GAP_RATIO / 2))

    ranges = _projection_ranges(col_profile, min_gap=min_gap)
    words = [line_image[:, x0:x1 + 1] for (x0, x1) in ranges if (x1 - x0) >= config.MIN_CHAR_DIM]

    if not words:
        raise SegmentationError("No words detected in line image.")
    return words


def segment_characters(word_image: np.ndarray) -> List[Tuple[np.ndarray, BoundingBox]]:
    """
    Split a single word image into individual character glyphs using
    connected-component contour analysis, sorted left-to-right.

    Returns
    -------
    list of (glyph_image, BoundingBox)
    """
    if word_image is None or word_image.size == 0:
        raise EmptyImageError("Cannot segment characters from an empty word image.")

    contours, _ = cv2.findContours(
        word_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )

    boxes = []
    for c in contours:
        area = cv2.contourArea(c)
        x, y, w, h = cv2.boundingRect(c)
        if area < config.MIN_CHAR_CONTOUR_AREA and (w < config.MIN_CHAR_DIM or h < config.MIN_CHAR_DIM):
            continue
        if w < 1 or h < 1:
            continue
        boxes.append(BoundingBox(x, y, w, h))

    if not boxes:
        raise SegmentationError("No character-like contours found in word image.")

    # Merge boxes that overlap heavily on the x-axis (common for characters
    # like 'i' or accented letters that produce multiple contours).
    boxes = sorted(boxes, key=lambda b: b.x)
    merged: List[BoundingBox] = []
    for b in boxes:
        if merged and b.x < merged[-1].x + merged[-1].w * 0.4:
            prev = merged[-1]
            x0 = min(prev.x, b.x)
            y0 = min(prev.y, b.y)
            x1 = max(prev.x + prev.w, b.x + b.w)
            y1 = max(prev.y + prev.h, b.y + b.h)
            merged[-1] = BoundingBox(x0, y0, x1 - x0, y1 - y0)
        else:
            merged.append(b)

    glyphs = []
    for b in merged:
        glyph = word_image[b.y:b.y + b.h, b.x:b.x + b.w]
        glyphs.append((glyph, b))

    return glyphs
