"""
inference/ocr_engine.py
========================
The main entry point for running OCR on a new image. Ties together:
  1. preprocessing.pipeline  (load, clean, binarize)
  2. inference.segmentation  (lines -> words -> characters)
  3. models.classifier       (per-character prediction + confidence)

into a single `OCREngine.recognize(image_path)` call that returns the
transcribed text plus per-character confidence scores.
"""

import os
from dataclasses import dataclass, field
from typing import List

import numpy as np

import config
from errors import OCRError, SegmentationError, EmptyImageError
from models.classifier import CharacterClassifier
from preprocessing.pipeline import preprocess_image, normalize_glyph
from inference.segmentation import segment_lines, segment_words, segment_characters


@dataclass
class CharacterResult:
    char: str
    confidence: float


@dataclass
class OCRResult:
    text: str
    mean_confidence: float
    low_confidence_chars: int
    characters: List[CharacterResult] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def __str__(self):
        return self.text


class OCREngine:
    """High-level handwritten OCR engine."""

    LOW_CONFIDENCE_THRESHOLD = 0.5

    def __init__(self, model_path: str = None, metadata_path: str = None):
        model_path = model_path or config.MODEL_PATH
        metadata_path = metadata_path or config.MODEL_METADATA_PATH
        self.classifier = CharacterClassifier.load(model_path, metadata_path)

    def recognize(self, image_input, method: str = "otsu") -> OCRResult:
        """
        Run full OCR on an image.

        Parameters
        ----------
        image_input : str or np.ndarray
            Path to an image file, or an already-loaded numpy array.
        method : {"otsu", "adaptive"}
            Thresholding strategy passed through to the preprocessor.

        Returns
        -------
        OCRResult

        Raises
        ------
        OCRError (or a subclass)
            On any invalid input, unreadable file, or a page with no
            detectable text.
        """
        binary = preprocess_image(image_input, method=method)

        warnings: List[str] = []
        try:
            lines = segment_lines(binary)
        except SegmentationError as e:
            raise SegmentationError(f"Could not segment any text lines: {e}") from e

        transcribed_lines = []
        all_char_results: List[CharacterResult] = []

        for line_img in lines:
            try:
                words = segment_words(line_img)
            except SegmentationError:
                warnings.append("A detected line contained no segmentable words; skipped.")
                continue

            transcribed_words = []
            for word_img in words:
                try:
                    glyphs = segment_characters(word_img)
                except SegmentationError:
                    warnings.append("A detected word contained no segmentable characters; skipped.")
                    continue

                word_str, char_results = self._classify_glyphs(glyphs)
                transcribed_words.append(word_str)
                all_char_results.extend(char_results)

            transcribed_lines.append(" ".join(transcribed_words))

        text = "\n".join(transcribed_lines)

        if not all_char_results:
            raise SegmentationError(
                "Preprocessing and segmentation succeeded, but no characters "
                "could be classified from this image."
            )

        confidences = [c.confidence for c in all_char_results]
        low_conf_count = sum(1 for c in confidences if c < self.LOW_CONFIDENCE_THRESHOLD)
        if low_conf_count:
            warnings.append(
                f"{low_conf_count}/{len(confidences)} characters were recognized "
                f"with low confidence (<{self.LOW_CONFIDENCE_THRESHOLD}); result may "
                f"contain errors."
            )

        return OCRResult(
            text=text,
            mean_confidence=float(np.mean(confidences)),
            low_confidence_chars=low_conf_count,
            characters=all_char_results,
            warnings=warnings,
        )

    def recognize_single_character(self, glyph_image: np.ndarray) -> CharacterResult:
        """Classify a single, already-cropped character glyph directly
        (bypasses segmentation) -- useful for testing or building custom
        pipelines on top of the classifier."""
        normalized = normalize_glyph(glyph_image, config.CHAR_IMAGE_SIZE)
        feature = normalized.flatten().reshape(1, -1)
        char, confidence = self.classifier.predict_with_confidence(feature)[0]
        return CharacterResult(char=char, confidence=confidence)

    def _classify_glyphs(self, glyphs) -> (str, List[CharacterResult]):
        features = np.zeros(
            (len(glyphs), config.CHAR_IMAGE_SIZE[0] * config.CHAR_IMAGE_SIZE[1]),
            dtype=np.float32,
        )
        for i, (glyph, _box) in enumerate(glyphs):
            normalized = normalize_glyph(glyph, config.CHAR_IMAGE_SIZE)
            features[i] = normalized.flatten()

        predictions = self.classifier.predict_with_confidence(features)
        char_results = [CharacterResult(char=c, confidence=conf) for c, conf in predictions]
        word_str = "".join(r.char for r in char_results)
        return word_str, char_results


def recognize_text(image_path: str, model_path: str = None, metadata_path: str = None) -> str:
    """Convenience one-shot function: image path in, recognized text out."""
    engine = OCREngine(model_path=model_path, metadata_path=metadata_path)
    result = engine.recognize(image_path)
    return result.text
