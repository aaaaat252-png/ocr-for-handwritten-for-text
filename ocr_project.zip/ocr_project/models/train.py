"""
models/train.py
================
Orchestrates loading data, training the CharacterClassifier, evaluating
it, and persisting the trained model + metadata to disk.
"""

import os
import time

import numpy as np

import config
from data.dataset_loader import (
    load_digits_dataset,
    load_emnist_from_csv,
    prepare_training_arrays,
    train_val_split,
)
from evaluation.metrics import character_accuracy, classification_report_dict
from models.classifier import CharacterClassifier


def train_and_evaluate(emnist_csv_path: str = None, verbose: bool = True) -> dict:
    """
    Full training run: load data -> prepare features -> train -> evaluate
    -> save model. Returns a dict of summary metrics.

    Parameters
    ----------
    emnist_csv_path : str, optional
        If provided, trains on an EMNIST-format CSV instead of the
        built-in digits dataset (see data/dataset_loader.py docstring).
    """
    np.random.seed(config.RANDOM_SEED)

    if verbose:
        print("[1/5] Loading dataset...")
    if emnist_csv_path:
        images, labels, label_map = load_emnist_from_csv(emnist_csv_path)
    else:
        images, labels, label_map = load_digits_dataset()
    if verbose:
        print(f"      Loaded {len(labels)} samples across {len(set(labels.tolist()))} classes.")

    if verbose:
        print("[2/5] Preprocessing & extracting features (train/inference parity)...")
    X, y = prepare_training_arrays(images, labels)
    X_train, X_val, y_train, y_val = train_val_split(X, y)
    if verbose:
        print(f"      Train: {X_train.shape[0]} samples | Validation: {X_val.shape[0]} samples")

    if verbose:
        print("[3/5] Training MLPClassifier...")
    start = time.time()
    clf = CharacterClassifier(label_map=label_map)
    clf.fit(X_train, y_train)
    elapsed = time.time() - start
    if verbose:
        print(f"      Training completed in {elapsed:.1f}s")

    if verbose:
        print("[4/5] Evaluating on validation set...")
    y_pred = clf.predict(X_val)
    acc = character_accuracy(y_val, y_pred)
    report = classification_report_dict(y_val, y_pred, label_map)
    if verbose:
        print(f"      Character-level validation accuracy: {acc * 100:.2f}%")
        if acc < config.TARGET_CHAR_ACCURACY:
            print(
                f"      WARNING: accuracy is below the {config.TARGET_CHAR_ACCURACY * 100:.0f}% "
                f"target. Consider more training data, hyperparameter tuning, "
                f"or the full EMNIST dataset (see README)."
            )

    if verbose:
        print("[5/5] Saving model...")
    os.makedirs(config.SAVED_MODELS_DIR, exist_ok=True)
    clf.save(config.MODEL_PATH, config.MODEL_METADATA_PATH)
    if verbose:
        print(f"      Saved to {config.MODEL_PATH}")

    return {
        "char_accuracy": acc,
        "n_train": int(X_train.shape[0]),
        "n_val": int(X_val.shape[0]),
        "n_classes": len(label_map),
        "training_seconds": elapsed,
        "report": report,
    }


if __name__ == "__main__":
    train_and_evaluate()
