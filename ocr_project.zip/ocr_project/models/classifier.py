"""
models/classifier.py
=====================
Thin wrapper around a scikit-learn pipeline (StandardScaler + MLPClassifier)
specialized for single-character recognition. Wrapping it in a class keeps
save/load, label-mapping, and confidence scoring in one place instead of
scattered through training/inference scripts.
"""

from typing import Dict, List, Tuple

import joblib
import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

import config
from errors import ModelNotTrainedError


class CharacterClassifier:
    """A trainable, persistable single-character image classifier."""

    def __init__(self, label_map: Dict[int, str] = None):
        self.label_map: Dict[int, str] = label_map or {}
        self.pipeline: Pipeline = Pipeline([
            ("scaler", StandardScaler()),
            ("mlp", MLPClassifier(
                hidden_layer_sizes=config.MLP_HIDDEN_LAYER_SIZES,
                activation=config.MLP_ACTIVATION,
                alpha=config.MLP_ALPHA,
                max_iter=config.MLP_MAX_ITER,
                early_stopping=config.MLP_EARLY_STOPPING,
                random_state=config.RANDOM_SEED,
            )),
        ])
        self._is_trained = False

    def fit(self, X: np.ndarray, y: np.ndarray) -> "CharacterClassifier":
        self.pipeline.fit(X, y)
        self._is_trained = True
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        self._check_trained()
        return self.pipeline.predict(X)

    def predict_with_confidence(self, X: np.ndarray) -> List[Tuple[str, float]]:
        """
        Predict labels for a batch of feature vectors, returning the
        human-readable character and the model's confidence (max class
        probability) for each.
        """
        self._check_trained()
        probs = self.pipeline.predict_proba(X)
        class_indices = self.pipeline.named_steps["mlp"].classes_
        results = []
        for row in probs:
            best_idx = int(np.argmax(row))
            class_label = int(class_indices[best_idx])
            confidence = float(row[best_idx])
            char = self.label_map.get(class_label, str(class_label))
            results.append((char, confidence))
        return results

    def score(self, X: np.ndarray, y: np.ndarray) -> float:
        self._check_trained()
        return self.pipeline.score(X, y)

    def _check_trained(self):
        if not self._is_trained:
            raise ModelNotTrainedError(
                "CharacterClassifier.fit() has not been called and no "
                "trained model has been loaded. Train or load a model "
                "before running inference."
            )

    # -- persistence ---------------------------------------------------
    def save(self, model_path: str, metadata_path: str) -> None:
        self._check_trained()
        joblib.dump(self.pipeline, model_path)
        joblib.dump({"label_map": self.label_map}, metadata_path)

    @classmethod
    def load(cls, model_path: str, metadata_path: str) -> "CharacterClassifier":
        try:
            pipeline = joblib.load(model_path)
            metadata = joblib.load(metadata_path)
        except FileNotFoundError as e:
            raise ModelNotTrainedError(
                f"Could not find a saved model at '{model_path}' / "
                f"'{metadata_path}'. Run `python scripts/train_model.py` "
                f"first."
            ) from e

        instance = cls(label_map=metadata.get("label_map", {}))
        instance.pipeline = pipeline
        instance._is_trained = True
        return instance
