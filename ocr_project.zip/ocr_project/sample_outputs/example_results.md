| Image | Ground Truth | Recognized | Mean Confidence | Match |
|---|---|---|---|---|
| sample_single_digit_7.png | 7 | 7 | 1.000 | Yes (9ms) |
| sample_sequence_12345.png | 12345 | 12345 | 0.982 | Yes (17ms) |
| sample_sequence_90210.png | 90210 | 90210 | 0.981 | Yes (18ms) |
| sample_sequence_2024.png | 2024 | 2024 | 0.995 | Yes (16ms) |
