# Handwritten OCR System

A production-structured, end-to-end handwritten character recognition (OCR)
system built with **OpenCV** (preprocessing/segmentation) and **scikit-learn**
(classification). It takes an image of handwritten text and returns
machine-readable text, with full error handling, unit tests, and evaluation
metrics.

```
Image  ->  Preprocess (OpenCV)  ->  Segment (lines/words/chars)  ->  Classify (sklearn)  ->  Text
```

## Results

Training on the bundled dataset (see **"About the dataset"** below):

| Metric | Value |
|---|---|
| Character-level validation accuracy | **96.67%** (target: >90%) |
| Validation set size | 360 samples (1,437 train / 360 val, stratified) |
| Model | MLPClassifier (256, 128) hidden layers, scikit-learn `Pipeline` |
| Training time | ~0.6s on CPU |

End-to-end example outputs (full pipeline: image file -> preprocessing ->
segmentation -> classification -> text), reproduced by
`sample_outputs/example_results.md`:

| Image | Ground Truth | Recognized | Mean Confidence | Match |
|---|---|---|---|---|
| sample_single_digit_7.png | 7 | 7 | 1.000 | Yes |
| sample_sequence_12345.png | 12345 | 12345 | 0.982 | Yes |
| sample_sequence_90210.png | 90210 | 90210 | 0.981 | Yes |
| sample_sequence_2024.png | 2024 | 2024 | 0.995 | Yes |

## About the dataset (please read)

This project is architected to train on **EMNIST** or **IAM Handwriting
Database** data, as requested. In practice, both have access constraints
that matter for reproducibility:

- **IAM** requires registering for a license and manually downloading the
  data from the university host — it cannot be fetched programmatically.
- **EMNIST** is normally fetched via `sklearn.datasets.fetch_openml`, which
  requires live network access to `openml.org`. Many environments
  (including the one this project was built and tested in) don't have a
  route to that host.

To keep the project **fully offline-reproducible out of the box**, the
default training path (`data/dataset_loader.load_digits_dataset`) uses
**`sklearn.datasets.load_digits`** — a bundled, real (not synthetic) dataset
of 1,797 handwritten digit glyphs (8x8 px, UCI ML repository, originally
scanned from actual handwritten forms). It is genuine handwritten character
data, just scoped to digits **0–9** rather than the full alphabet.

**To extend to letters (A–Z, a–z) with real EMNIST data**, the pipeline is
already built for it — see [Extending to the full alphabet](#extending-to-the-full-alphabet-emnistiam)
below. No architecture changes are needed, only pointing the loader at a
CSV file.

## Project structure

```
ocr_project/
├── config.py                  # All tunable parameters in one place
├── errors.py                  # Custom exception hierarchy
├── requirements.txt           # Pinned dependencies
├── data/
│   └── dataset_loader.py      # Dataset loading + train/inference feature parity
├── preprocessing/
│   └── pipeline.py            # OpenCV: grayscale, denoise, threshold, deskew, normalize
├── inference/
│   ├── segmentation.py        # Lines -> words -> characters (projection profiles + contours)
│   └── ocr_engine.py          # Orchestrates preprocess -> segment -> classify -> text
├── models/
│   ├── classifier.py          # sklearn Pipeline wrapper (train/predict/save/load)
│   └── train.py                # Training + evaluation orchestration
├── evaluation/
│   └── metrics.py             # Character/word accuracy, CER, confidence stats
├── scripts/
│   ├── train_model.py         # CLI: train and save the model
│   └── run_inference.py       # CLI: run OCR on an image
├── examples/
│   └── generate_sample_images.py  # Builds demo images + error-case fixtures
├── tests/                     # 88 unit tests across all modules (pytest)
└── saved_models/              # Trained model artifacts (.joblib)
```

## Setup

```bash
cd ocr_project
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Quick start

**1. Train the model** (uses the bundled digits dataset by default):

```bash
python scripts/train_model.py
```

This prints per-stage progress and a final accuracy summary, and saves the
trained model to `saved_models/character_classifier.joblib` plus its label
map to `saved_models/model_metadata.joblib`.

**2. Generate sample test images** (optional — creates demo/test fixtures
from real handwritten-digit glyphs, plus deliberately invalid files for
exercising error handling):

```bash
python examples/generate_sample_images.py
```

**3. Run OCR on an image:**

```bash
python scripts/run_inference.py --image examples/sample_images/sample_sequence_12345.png
python scripts/run_inference.py --image path/to/your/image.png --show-confidence
```

Output:
```
=== Recognized text ===
12345

Mean confidence: 0.982
```

**4. Run the tests:**

```bash
python -m pytest
```

## Using it from Python

```python
from inference.ocr_engine import OCREngine

engine = OCREngine()  # loads saved_models/character_classifier.joblib
result = engine.recognize("path/to/handwriting.png")

print(result.text)              # the recognized text
print(result.mean_confidence)   # 0.0-1.0
print(result.warnings)          # e.g. low-confidence character warnings
for c in result.characters:     # per-character breakdown
    print(c.char, c.confidence)
```

Or the one-line convenience function:

```python
from inference.ocr_engine import recognize_text
text = recognize_text("path/to/handwriting.png")
```

## How it works

### 1. Preprocessing (`preprocessing/pipeline.py`, OpenCV)
1. **Load & validate** — decode the file, reject corrupt/unsupported/empty
   files with a descriptive error before any processing begins.
2. **Grayscale** — `cv2.cvtColor` (handles BGR, BGRA, and already-gray input).
3. **Denoise** — Gaussian blur + `cv2.fastNlMeansDenoising` to remove
   scanner/camera speckle without destroying thin pen strokes.
4. **Threshold** — Otsu's method (default) or adaptive Gaussian thresholding
   for uneven lighting, producing a binary image with text as white
   foreground on a black background (auto-detects and corrects inverted
   polarity).
5. **Deskew** — estimates rotation via `cv2.minAreaRect` over foreground
   pixels and rotates to correct small skew; safely no-ops on blank or
   already-straight input.

### 2. Segmentation (`inference/segmentation.py`)
1. **Lines** — horizontal projection profile (row-wise foreground pixel
   sums); contiguous bands become lines.
2. **Words** — vertical projection profile within each line; gaps wider
   than a threshold (relative to line height) become word boundaries.
3. **Characters** — connected-component contour detection within each
   word, sorted left-to-right, with small nearby contours merged (handles
   characters like "i" that produce multiple contours) and noise-sized
   contours filtered out.

### 3. Classification (`models/classifier.py`)
Each segmented glyph is normalized (aspect-ratio-preserving resize + pad to
28×28, scaled to [0,1] — see `preprocessing.pipeline.normalize_glyph`, used
identically at train and inference time to avoid train/serve skew) and
classified by a `scikit-learn` `Pipeline` of `StandardScaler` +
`MLPClassifier`. `predict_with_confidence` returns both the predicted
character and the model's confidence (max softmax probability).

### 4. Assembly (`inference/ocr_engine.py`)
Per-character predictions are joined into words (space-separated) and lines
(newline-separated) to produce the final text, along with aggregate and
per-character confidence scores and any warnings (e.g. unsegmentable
regions, low-confidence characters).

## Error handling

All failure modes raise a specific subclass of `errors.OCRError` with a
descriptive message, rather than a bare exception or a silent `None`:

| Exception | Raised when |
|---|---|
| `InvalidImageError` | Path doesn't exist, wrong type, is a directory, or the array is malformed |
| `UnsupportedFormatError` | Unsupported extension, corrupt file, empty (0-byte) file, undecodable content |
| `EmptyImageError` | Zero-size array, too-small image, or a blank page with no ink after thresholding |
| `SegmentationError` | No lines/words/characters could be found in an otherwise-valid image |
| `ModelNotTrainedError` | Inference attempted before a model is trained/loaded |

Example:

```python
from errors import OCRError
try:
    result = engine.recognize("scan.png")
except OCRError as e:
    print(f"OCR failed: {e}")   # human-readable, actionable message
```

## Evaluation metrics (`evaluation/metrics.py`)

- `character_accuracy(y_true, y_pred)` — fraction of correctly classified characters
- `word_accuracy(true_words, pred_words)` — fraction of whole words with zero errors
- `levenshtein_distance` / `character_error_rate` — edit-distance-based CER
- `confidence_stats` — mean/min/max/std of confidence scores over a batch
- `classification_report_dict` — per-class precision/recall/F1

## Testing

88 tests across 5 files, run with `pytest`:

- `tests/test_preprocessing.py` — grayscale, denoise, binarize, deskew,
  normalize, and the full pipeline, including corrupt files, wrong
  extensions, empty files, blank pages, and non-array inputs.
- `tests/test_segmentation.py` — line/word/character splitting, noise
  filtering, and blank/empty-input error paths.
- `tests/test_classifier.py` — fit/predict/confidence/save/load, and the
  "used before trained" error path.
- `tests/test_inference.py` — end-to-end recognition against real sample
  images with known ground truth (asserts the >90% accuracy target),
  confidence score ranges, and every error path (missing file, blank page,
  corrupt file, wrong extension, `None` input, missing model).
- `tests/test_errors.py` — exception hierarchy and metric-function edge
  cases (empty inputs, mismatched lengths, etc.).

```bash
python -m pytest                 # run everything
python -m pytest tests/test_preprocessing.py -v   # one module
python -m pytest -k "error"       # just error-handling tests
```

## Reproducibility

- `config.RANDOM_SEED = 42` is used everywhere randomness occurs: the
  train/validation split, `MLPClassifier` weight initialization, and the
  sample-image glyph selection in `examples/generate_sample_images.py`.
  Re-running `train_model.py` produces the same accuracy every time
  (verified: 96.67% across repeated runs).
- All dependencies are pinned to exact versions in `requirements.txt`.
- Train-time and inference-time preprocessing share the exact same
  `normalize_glyph` function, so there is no train/serve skew.

## Extending to the full alphabet (EMNIST/IAM)

The pipeline is dataset-agnostic by design — only `data/dataset_loader.py`
needs a data source; nothing else changes.

**Option A — EMNIST CSV (fastest path to A–Z/a–z):**
1. Download an EMNIST CSV export (e.g. `emnist-balanced-train.csv`) from
   the [official EMNIST page](https://www.nist.gov/itl/products-and-services/emnist-dataset)
   or via `pip install emnist` (fetches from NIST).
2. Train directly against it:
   ```bash
   python scripts/train_model.py --emnist-csv path/to/emnist-balanced-train.csv
   ```
   `data/dataset_loader.load_emnist_from_csv` already handles the
   label-to-character mapping (0–9 digits, 10–35 upper, 36–61 lower) and
   EMNIST's transposed pixel layout.

**Option B — IAM Handwriting Database (full words/lines, not just
characters):** IAM provides line- and word-level images with transcriptions
rather than isolated characters. To use it:
1. Register and download the IAM dataset (requires a free academic license).
2. Write a loader that crops IAM's word-level bounding boxes into
   individual character glyphs using their character-level XML annotations
   (IAM does not ship pre-segmented characters), matching the
   `(images, labels, label_map)` signature of the existing loaders.
3. Everything downstream (`prepare_training_arrays`, `CharacterClassifier`,
   `OCREngine`) works unchanged.

**Option C — swap the classifier:** For harder handwriting (cursive, more
classes), swap `MLPClassifier` in `models/classifier.py` for
`sklearn.svm.SVC(probability=True)` or tune
`config.MLP_HIDDEN_LAYER_SIZES` — no other file needs to change.

## Assumptions & limitations

- **Character set**: the shipped model recognizes digits 0–9 only (a direct
  consequence of the offline-reproducibility tradeoff explained above).
  The architecture supports the full alphabet immediately given EMNIST/IAM
  data (see above).
- **Segmentation-based, not sequence-based**: characters are classified
  independently after segmentation, rather than with a sequence model
  (e.g. CTC/RNN) that could use surrounding-character context. This is a
  deliberate consequence of using scikit-learn (as specified) rather than
  a deep learning framework; it works well for clearly-separated print/
  block handwriting but will degrade on heavily cursive, joined-up script
  where character boundaries are ambiguous.
- **Single glyph per contour assumption**: segmentation merges nearby
  contours and filters small ones, but very ornate handwriting, touching
  characters, or heavy noise can still cause over/under-segmentation.
- **Confidence scores** are the classifier's max softmax probability, a
  reasonable but imperfect proxy for correctness — always spot-check
  low-confidence output (`result.warnings` flags this automatically).
- **Language**: no spell-checking, dictionary, or language model is
  applied; output is a raw character-by-character transcription.

## Configuration

All tunable parameters (image sizes, thresholds, model hyperparameters,
segmentation gap ratios, the accuracy target) live in `config.py` — see
that file for inline documentation of every setting.
