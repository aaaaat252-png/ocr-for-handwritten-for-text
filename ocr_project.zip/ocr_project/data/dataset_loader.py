"""
data/dataset_loader.py
=======================
Loads and prepares handwritten-character training data.

Dataset note (read this first)
-------------------------------
This project is designed to train on EMNIST or IAM-style handwriting
data. However, both require either a licensed download (IAM) or a
large network fetch from openml.org (EMNIST via
`sklearn.datasets.fetch_openml`), neither of which is available in
every environment (including the sandbox this project was authored in,
which has no route to openml.org).

To keep the project fully reproducible and runnable offline, the
default training path uses `sklearn.datasets.load_digits` -- a
bundled, real (not synthetic) dataset of 1,797 handwritten digit
glyphs (8x8, from the UCI ML repository, originally scanned from
handwritten forms). This is genuine handwritten character data, just
scoped to digits 0-9 rather than the full alphabet.

`load_emnist_from_csv()` below is provided so you can drop in the real
EMNIST-letters or EMNIST-balanced CSV export (available from
https://www.nist.gov/itl/products-and-services/emnist-dataset or via
`pip install emnist`) and immediately train a full alphanumeric model
with no other code changes -- see README.md "Extending to letters".
"""

import os
from typing import Tuple

import numpy as np
import pandas as pd
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

import config
from errors import InvalidImageError
from preprocessing.pipeline import normalize_glyph


def load_digits_dataset() -> Tuple[np.ndarray, np.ndarray, dict]:
    """
    Load the built-in handwritten digits dataset.

    Returns
    -------
    images : np.ndarray, shape (N, 8, 8), dtype float, values 0-16
        Raw glyph images as provided by sklearn.
    labels : np.ndarray, shape (N,)
        Integer class labels 0-9.
    label_map : dict[int, str]
        Maps class index -> human-readable character.
    """
    digits = load_digits()
    label_map = {i: str(i) for i in range(10)}
    return digits.images, digits.target, label_map


def load_emnist_from_csv(csv_path: str, image_size: int = 28) -> Tuple[np.ndarray, np.ndarray, dict]:
    """
    Load an EMNIST-format CSV (label, pixel0, pixel1, ..., pixelN) such as
    the ones distributed by the official EMNIST CSV export. This lets the
    same training pipeline scale from 10 digit classes to the full 47/62
    class EMNIST alphabet without any other code changes.

    Raises
    ------
    InvalidImageError
        If the file doesn't exist or doesn't match the expected format.
    """
    if not os.path.exists(csv_path):
        raise InvalidImageError(f"EMNIST CSV not found: '{csv_path}'")

    df = pd.read_csv(csv_path, header=None)
    expected_cols = image_size * image_size + 1
    if df.shape[1] != expected_cols:
        raise InvalidImageError(
            f"Expected {expected_cols} columns (1 label + {image_size * image_size} "
            f"pixels) but got {df.shape[1]} in '{csv_path}'."
        )

    labels = df.iloc[:, 0].to_numpy()
    pixels = df.iloc[:, 1:].to_numpy(dtype=np.float32)
    images = pixels.reshape(-1, image_size, image_size)

    # EMNIST images are stored transposed relative to normal reading order.
    images = np.transpose(images, (0, 2, 1))

    unique_labels = sorted(np.unique(labels).tolist())
    # Default EMNIST "byclass"/"balanced" mapping: 0-9 digits, 10-35 upper,
    # 36-61 lower. Users with a different mapping file can override this.
    label_map = {}
    for lbl in unique_labels:
        if 0 <= lbl <= 9:
            label_map[lbl] = str(lbl)
        elif 10 <= lbl <= 35:
            label_map[lbl] = chr(ord("A") + lbl - 10)
        elif 36 <= lbl <= 61:
            label_map[lbl] = chr(ord("a") + lbl - 36)
        else:
            label_map[lbl] = f"?{lbl}"

    return images, labels, label_map


def prepare_training_arrays(images: np.ndarray, labels: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """
    Convert raw glyph images (any size, any value range) into flattened,
    normalized feature vectors ready for a scikit-learn classifier, using
    the exact same `normalize_glyph` transform used at inference time.
    This ensures train/inference preprocessing parity, a common source of
    silent accuracy loss in OCR systems.
    """
    n = images.shape[0]
    features = np.zeros((n, config.CHAR_IMAGE_SIZE[0] * config.CHAR_IMAGE_SIZE[1]), dtype=np.float32)

    for i in range(n):
        img = images[i]
        # Scale to 0-255 uint8 as normalize_glyph expects a binary-ish glyph.
        img_max = img.max() if img.max() > 0 else 1.0
        img_uint8 = np.clip((img / img_max) * 255.0, 0, 255).astype(np.uint8)
        normalized = normalize_glyph(img_uint8, config.CHAR_IMAGE_SIZE)
        features[i] = normalized.flatten()

    return features, labels.astype(np.int64)


def train_val_split(X: np.ndarray, y: np.ndarray):
    """Stratified train/validation split using the project's fixed seed."""
    return train_test_split(
        X, y,
        test_size=config.VALIDATION_SPLIT,
        random_state=config.RANDOM_SEED,
        stratify=y,
    )
