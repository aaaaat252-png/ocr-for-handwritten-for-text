"""
errors.py
=========
Custom exception hierarchy for the OCR system. Using specific exception
types (instead of bare ValueError/Exception everywhere) lets calling code
-- and unit tests -- distinguish between failure modes and lets us attach
clear, actionable messages for each one.
"""


class OCRError(Exception):
    """Base class for all errors raised by this OCR system."""


class InvalidImageError(OCRError):
    """Raised when an image path/array cannot be loaded or is malformed."""


class EmptyImageError(OCRError):
    """Raised when an image is valid but contains no usable content
    (zero-size array, fully blank/uniform canvas, etc.)."""


class UnsupportedFormatError(OCRError):
    """Raised when a file exists but is not a supported/decodable image
    format (e.g. a .txt file renamed to .png, a truncated file, ...)."""


class ModelNotTrainedError(OCRError):
    """Raised when inference is attempted before a model has been
    trained or loaded from disk."""


class SegmentationError(OCRError):
    """Raised when the segmentation stage cannot find any character-like
    regions to classify."""
