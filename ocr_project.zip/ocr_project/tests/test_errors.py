"""
tests/test_errors.py
======================
Cross-cutting edge-case and error-handling tests that don't belong to a
single module: malformed inputs, wrong types, zero-size data, and
metric-function edge cases.
"""

import numpy as np
import pytest

from errors import EmptyImageError, InvalidImageError, OCRError, UnsupportedFormatError
from evaluation.metrics import (
    character_accuracy,
    character_error_rate,
    confidence_stats,
    levenshtein_distance,
    word_accuracy,
)
from preprocessing.pipeline import load_image, validate_image


class TestErrorHierarchy:
    """All specific errors must subclass the common OCRError base so
    calling code can catch broadly or narrowly as needed."""

    @pytest.mark.parametrize("exc_cls", [InvalidImageError, EmptyImageError, UnsupportedFormatError])
    def test_is_subclass_of_ocr_error(self, exc_cls):
        assert issubclass(exc_cls, OCRError)

    def test_error_messages_are_descriptive(self):
        with pytest.raises(InvalidImageError, match="does not exist"):
            load_image("/definitely/not/a/real/path.png")


class TestValidateImageEdgeCases:
    def test_wrong_type_list(self):
        with pytest.raises(InvalidImageError):
            validate_image("not an array")

    def test_wrong_type_int(self):
        with pytest.raises(InvalidImageError):
            validate_image(42)

    def test_negative_dim_like_object(self):
        with pytest.raises(InvalidImageError):
            validate_image(np.zeros((5, 5, 5, 5, 5)))


class TestMetricsEdgeCases:
    def test_character_accuracy_perfect(self):
        assert character_accuracy(["a", "b", "c"], ["a", "b", "c"]) == 1.0

    def test_character_accuracy_zero(self):
        assert character_accuracy(["a", "b"], ["x", "y"]) == 0.0

    def test_character_accuracy_empty_inputs(self):
        assert character_accuracy([], []) == 0.0

    def test_character_accuracy_mismatched_length_raises(self):
        with pytest.raises(ValueError):
            character_accuracy(["a", "b"], ["a"])

    def test_word_accuracy_basic(self):
        assert word_accuracy(["cat", "dog"], ["cat", "cog"]) == 0.5

    def test_word_accuracy_mismatched_length_raises(self):
        with pytest.raises(ValueError):
            word_accuracy(["cat"], ["cat", "dog"])

    def test_levenshtein_identical_strings(self):
        assert levenshtein_distance("hello", "hello") == 0

    def test_levenshtein_empty_strings(self):
        assert levenshtein_distance("", "abc") == 3
        assert levenshtein_distance("abc", "") == 3
        assert levenshtein_distance("", "") == 0

    def test_levenshtein_known_case(self):
        assert levenshtein_distance("kitten", "sitting") == 3

    def test_character_error_rate_perfect_match(self):
        assert character_error_rate("hello", "hello") == 0.0

    def test_character_error_rate_empty_reference(self):
        assert character_error_rate("", "") == 0.0
        assert character_error_rate("", "abc") == 1.0

    def test_confidence_stats_empty(self):
        stats = confidence_stats([])
        assert stats == {"mean": 0.0, "min": 0.0, "max": 0.0, "std": 0.0}

    def test_confidence_stats_basic(self):
        stats = confidence_stats([0.5, 0.9, 0.7])
        assert stats["min"] == 0.5
        assert stats["max"] == 0.9
        assert pytest.approx(stats["mean"], rel=1e-6) == 0.7
