"""
tests/test_preprocessing.py
=============================
Unit tests for preprocessing/pipeline.py: grayscaling, thresholding,
denoising, deskewing, normalization, and their error-handling paths.
"""

import os

import cv2
import numpy as np
import pytest

from errors import EmptyImageError, InvalidImageError, UnsupportedFormatError
from preprocessing.pipeline import (
    binarize,
    deskew,
    load_image,
    normalize_glyph,
    preprocess_image,
    to_grayscale,
    validate_image,
)

FIXTURES_DIR = os.path.join(os.path.dirname(__file__), "fixtures")


@pytest.fixture(scope="module", autouse=True)
def make_fixtures():
    """Create small on-disk image fixtures used across preprocessing tests."""
    os.makedirs(FIXTURES_DIR, exist_ok=True)

    # A simple 100x100 white canvas with a black square "glyph" on it.
    img = np.full((100, 100, 3), 255, dtype=np.uint8)
    cv2.rectangle(img, (30, 30), (70, 70), (0, 0, 0), -1)
    cv2.imwrite(os.path.join(FIXTURES_DIR, "valid_glyph.png"), img)

    # A blank (fully white) page.
    blank = np.full((100, 100, 3), 255, dtype=np.uint8)
    cv2.imwrite(os.path.join(FIXTURES_DIR, "blank.png"), blank)

    # A corrupt "image" file (valid extension, garbage bytes).
    with open(os.path.join(FIXTURES_DIR, "corrupt.png"), "wb") as f:
        f.write(b"not a real png file")

    # A text file masquerading as an image via extension.
    with open(os.path.join(FIXTURES_DIR, "wrong_ext.jpg"), "w") as f:
        f.write("hello world, not an image")

    yield


# ---------------------------------------------------------------------------
# load_image
# ---------------------------------------------------------------------------
class TestLoadImage:
    def test_loads_valid_image(self):
        img = load_image(os.path.join(FIXTURES_DIR, "valid_glyph.png"))
        assert isinstance(img, np.ndarray)
        assert img.ndim == 3

    def test_nonexistent_path_raises(self):
        with pytest.raises(InvalidImageError):
            load_image(os.path.join(FIXTURES_DIR, "does_not_exist.png"))

    def test_non_string_path_raises(self):
        with pytest.raises(InvalidImageError):
            load_image(12345)

    def test_directory_path_raises(self):
        with pytest.raises(InvalidImageError):
            load_image(FIXTURES_DIR)

    def test_unsupported_extension_raises(self):
        bad_ext_path = os.path.join(FIXTURES_DIR, "unsupported.gif")
        with open(bad_ext_path, "wb") as f:
            f.write(b"GIF89a")
        with pytest.raises(UnsupportedFormatError):
            load_image(bad_ext_path)

    def test_corrupt_file_raises(self):
        with pytest.raises(UnsupportedFormatError):
            load_image(os.path.join(FIXTURES_DIR, "corrupt.png"))

    def test_wrong_content_for_extension_raises(self):
        with pytest.raises(UnsupportedFormatError):
            load_image(os.path.join(FIXTURES_DIR, "wrong_ext.jpg"))

    def test_empty_file_raises(self):
        empty_path = os.path.join(FIXTURES_DIR, "empty.png")
        open(empty_path, "wb").close()
        with pytest.raises(UnsupportedFormatError):
            load_image(empty_path)


# ---------------------------------------------------------------------------
# validate_image
# ---------------------------------------------------------------------------
class TestValidateImage:
    def test_none_raises(self):
        with pytest.raises(InvalidImageError):
            validate_image(None)

    def test_non_array_raises(self):
        with pytest.raises(InvalidImageError):
            validate_image([[1, 2], [3, 4]])

    def test_zero_size_array_raises(self):
        with pytest.raises(EmptyImageError):
            validate_image(np.array([]))

    def test_too_small_image_raises(self):
        with pytest.raises(EmptyImageError):
            validate_image(np.zeros((1, 1), dtype=np.uint8))

    def test_invalid_ndim_raises(self):
        with pytest.raises(InvalidImageError):
            validate_image(np.zeros((5, 5, 5, 5), dtype=np.uint8))

    def test_valid_grayscale_passes(self):
        validate_image(np.zeros((10, 10), dtype=np.uint8))  # should not raise

    def test_valid_color_passes(self):
        validate_image(np.zeros((10, 10, 3), dtype=np.uint8))  # should not raise


# ---------------------------------------------------------------------------
# to_grayscale
# ---------------------------------------------------------------------------
class TestToGrayscale:
    def test_color_to_grayscale(self):
        color = np.zeros((20, 20, 3), dtype=np.uint8)
        gray = to_grayscale(color)
        assert gray.ndim == 2
        assert gray.shape == (20, 20)

    def test_already_grayscale_passthrough(self):
        gray_in = np.zeros((20, 20), dtype=np.uint8)
        gray_out = to_grayscale(gray_in)
        assert gray_out.shape == (20, 20)

    def test_bgra_to_grayscale(self):
        bgra = np.zeros((20, 20, 4), dtype=np.uint8)
        gray = to_grayscale(bgra)
        assert gray.ndim == 2

    def test_invalid_input_raises(self):
        with pytest.raises(InvalidImageError):
            to_grayscale(None)


# ---------------------------------------------------------------------------
# binarize
# ---------------------------------------------------------------------------
class TestBinarize:
    def test_otsu_produces_binary_values(self):
        gray = cv2.imread(os.path.join(FIXTURES_DIR, "valid_glyph.png"), cv2.IMREAD_GRAYSCALE)
        binary = binarize(gray, method="otsu")
        unique_vals = set(np.unique(binary).tolist())
        assert unique_vals.issubset({0, 255})

    def test_adaptive_produces_binary_values(self):
        gray = cv2.imread(os.path.join(FIXTURES_DIR, "valid_glyph.png"), cv2.IMREAD_GRAYSCALE)
        binary = binarize(gray, method="adaptive")
        unique_vals = set(np.unique(binary).tolist())
        assert unique_vals.issubset({0, 255})

    def test_text_is_white_foreground_convention(self):
        gray = cv2.imread(os.path.join(FIXTURES_DIR, "valid_glyph.png"), cv2.IMREAD_GRAYSCALE)
        binary = binarize(gray, method="otsu")
        # The square glyph occupies a minority of the 100x100 canvas, so
        # foreground (white=255) pixel count should be less than half.
        assert np.count_nonzero(binary == 255) < binary.size / 2

    def test_invalid_method_raises(self):
        gray = np.zeros((10, 10), dtype=np.uint8)
        with pytest.raises(InvalidImageError):
            binarize(gray, method="not_a_real_method")


# ---------------------------------------------------------------------------
# deskew
# ---------------------------------------------------------------------------
class TestDeskew:
    def test_deskew_does_not_crash_on_blank(self):
        blank = np.zeros((50, 50), dtype=np.uint8)
        result = deskew(blank)
        assert result.shape == blank.shape

    def test_deskew_preserves_shape(self):
        binary = np.zeros((60, 80), dtype=np.uint8)
        cv2.rectangle(binary, (10, 10), (50, 40), 255, -1)
        result = deskew(binary)
        assert result.shape == binary.shape


# ---------------------------------------------------------------------------
# normalize_glyph
# ---------------------------------------------------------------------------
class TestNormalizeGlyph:
    def test_output_shape_matches_target(self):
        glyph = np.full((15, 22), 255, dtype=np.uint8)
        out = normalize_glyph(glyph, target_size=(28, 28))
        assert out.shape == (28, 28)

    def test_output_range_is_normalized(self):
        glyph = np.full((15, 22), 255, dtype=np.uint8)
        out = normalize_glyph(glyph, target_size=(28, 28))
        assert out.dtype == np.float32
        assert out.min() >= 0.0 and out.max() <= 1.0

    def test_preserves_aspect_ratio_without_distortion(self):
        # A wide glyph should not be stretched into a square blob that
        # fills the whole canvas -- padding should appear on top/bottom.
        wide_glyph = np.zeros((10, 40), dtype=np.uint8)
        wide_glyph[:, :] = 255
        out = normalize_glyph(wide_glyph, target_size=(28, 28))
        assert out.shape == (28, 28)

    def test_empty_glyph_raises(self):
        with pytest.raises(EmptyImageError):
            normalize_glyph(np.array([]), target_size=(28, 28))


# ---------------------------------------------------------------------------
# Full pipeline
# ---------------------------------------------------------------------------
class TestPreprocessImage:
    def test_full_pipeline_on_path(self):
        binary = preprocess_image(os.path.join(FIXTURES_DIR, "valid_glyph.png"))
        assert binary.ndim == 2
        assert set(np.unique(binary).tolist()).issubset({0, 255})

    def test_full_pipeline_on_array(self):
        img = cv2.imread(os.path.join(FIXTURES_DIR, "valid_glyph.png"))
        binary = preprocess_image(img)
        assert binary.ndim == 2

    def test_blank_page_raises_empty_image_error(self):
        with pytest.raises(EmptyImageError):
            preprocess_image(os.path.join(FIXTURES_DIR, "blank.png"))

    def test_nonexistent_path_raises(self):
        with pytest.raises(InvalidImageError):
            preprocess_image(os.path.join(FIXTURES_DIR, "nope.png"))

    def test_invalid_method_raises(self):
        with pytest.raises(InvalidImageError):
            preprocess_image(os.path.join(FIXTURES_DIR, "valid_glyph.png"), method="bogus")
