"""
tests/test_segmentation.py
============================
Unit tests for inference/segmentation.py: line/word/character splitting
and its error-handling paths on empty or content-free input.
"""

import numpy as np
import pytest
import cv2

from errors import EmptyImageError, SegmentationError
from inference.segmentation import segment_characters, segment_lines, segment_words


def _make_two_line_image():
    """A 100x200 binary image with two horizontal white bands (lines) of
    'text' separated by a blank gap."""
    img = np.zeros((100, 200), dtype=np.uint8)
    img[10:30, 20:180] = 255   # line 1
    img[60:80, 20:180] = 255   # line 2
    return img


def _make_two_word_line():
    """A single-line binary image with two separated blobs (words)."""
    img = np.zeros((40, 200), dtype=np.uint8)
    img[10:30, 10:60] = 255    # word 1
    img[10:30, 140:190] = 255  # word 2 (far gap => separate word)
    return img


def _make_multi_char_word():
    """A single-word binary image with three small separated blobs
    (characters) close enough together to be one word."""
    img = np.zeros((30, 100), dtype=np.uint8)
    img[5:25, 5:20] = 255
    img[5:25, 30:45] = 255
    img[5:25, 55:70] = 255
    return img


class TestSegmentLines:
    def test_detects_two_lines(self):
        img = _make_two_line_image()
        lines = segment_lines(img)
        assert len(lines) == 2

    def test_empty_image_raises(self):
        with pytest.raises(EmptyImageError):
            segment_lines(np.array([]))

    def test_blank_image_raises_segmentation_error(self):
        blank = np.zeros((50, 50), dtype=np.uint8)
        with pytest.raises(SegmentationError):
            segment_lines(blank)

    def test_single_line_image(self):
        img = np.zeros((40, 100), dtype=np.uint8)
        img[10:30, 10:90] = 255
        lines = segment_lines(img)
        assert len(lines) == 1


class TestSegmentWords:
    def test_detects_two_words(self):
        line = _make_two_word_line()
        words = segment_words(line)
        assert len(words) == 2

    def test_empty_image_raises(self):
        with pytest.raises(EmptyImageError):
            segment_words(np.array([]))

    def test_blank_line_raises_segmentation_error(self):
        blank = np.zeros((40, 200), dtype=np.uint8)
        with pytest.raises(SegmentationError):
            segment_words(blank)

    def test_single_word_line(self):
        img = np.zeros((40, 100), dtype=np.uint8)
        img[10:30, 10:90] = 255
        words = segment_words(img)
        assert len(words) == 1


class TestSegmentCharacters:
    def test_detects_three_characters(self):
        word = _make_multi_char_word()
        glyphs = segment_characters(word)
        assert len(glyphs) == 3
        for glyph, box in glyphs:
            assert glyph.size > 0
            assert box.w > 0 and box.h > 0

    def test_characters_sorted_left_to_right(self):
        word = _make_multi_char_word()
        glyphs = segment_characters(word)
        xs = [box.x for _, box in glyphs]
        assert xs == sorted(xs)

    def test_empty_image_raises(self):
        with pytest.raises(EmptyImageError):
            segment_characters(np.array([]))

    def test_blank_word_raises_segmentation_error(self):
        blank = np.zeros((30, 100), dtype=np.uint8)
        with pytest.raises(SegmentationError):
            segment_characters(blank)

    def test_single_character(self):
        img = np.zeros((30, 30), dtype=np.uint8)
        cv2.circle(img, (15, 15), 10, 255, -1)
        glyphs = segment_characters(img)
        assert len(glyphs) == 1

    def test_noise_speckle_filtered_out(self):
        img = np.zeros((30, 100), dtype=np.uint8)
        img[10:25, 10:25] = 255  # a real character
        img[2:3, 80:81] = 255    # a 1x1 speckle of noise
        glyphs = segment_characters(img)
        # The speckle should be filtered by MIN_CHAR_CONTOUR_AREA/MIN_CHAR_DIM
        assert len(glyphs) == 1
