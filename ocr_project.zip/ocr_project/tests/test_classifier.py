"""
tests/test_classifier.py
==========================
Unit tests for models/classifier.py: training, prediction, confidence
scoring, persistence, and the "used before trained" error path.
"""

import os
import tempfile

import numpy as np
import pytest
from sklearn.datasets import load_digits

from errors import ModelNotTrainedError
from models.classifier import CharacterClassifier


@pytest.fixture(scope="module")
def small_digit_data():
    digits = load_digits()
    X = digits.data[:300]
    y = digits.target[:300]
    return X, y


class TestCharacterClassifier:
    def test_predict_before_fit_raises(self):
        clf = CharacterClassifier()
        with pytest.raises(ModelNotTrainedError):
            clf.predict(np.zeros((1, 64)))

    def test_predict_with_confidence_before_fit_raises(self):
        clf = CharacterClassifier()
        with pytest.raises(ModelNotTrainedError):
            clf.predict_with_confidence(np.zeros((1, 64)))

    def test_fit_and_predict(self, small_digit_data):
        X, y = small_digit_data
        clf = CharacterClassifier(label_map={i: str(i) for i in range(10)})
        clf.fit(X, y)
        preds = clf.predict(X[:10])
        assert len(preds) == 10

    def test_predict_with_confidence_returns_valid_range(self, small_digit_data):
        X, y = small_digit_data
        clf = CharacterClassifier(label_map={i: str(i) for i in range(10)})
        clf.fit(X, y)
        results = clf.predict_with_confidence(X[:10])
        assert len(results) == 10
        for char, conf in results:
            assert isinstance(char, str)
            assert 0.0 <= conf <= 1.0

    def test_score(self, small_digit_data):
        X, y = small_digit_data
        clf = CharacterClassifier(label_map={i: str(i) for i in range(10)})
        clf.fit(X, y)
        acc = clf.score(X, y)
        assert 0.0 <= acc <= 1.0

    def test_save_and_load_roundtrip(self, small_digit_data):
        X, y = small_digit_data
        clf = CharacterClassifier(label_map={i: str(i) for i in range(10)})
        clf.fit(X, y)

        with tempfile.TemporaryDirectory() as tmpdir:
            model_path = os.path.join(tmpdir, "model.joblib")
            meta_path = os.path.join(tmpdir, "meta.joblib")
            clf.save(model_path, meta_path)

            loaded = CharacterClassifier.load(model_path, meta_path)
            original_preds = clf.predict(X[:10])
            loaded_preds = loaded.predict(X[:10])
            assert list(original_preds) == list(loaded_preds)
            assert loaded.label_map == clf.label_map

    def test_save_before_fit_raises(self):
        clf = CharacterClassifier()
        with tempfile.TemporaryDirectory() as tmpdir:
            with pytest.raises(ModelNotTrainedError):
                clf.save(os.path.join(tmpdir, "m.joblib"), os.path.join(tmpdir, "meta.joblib"))

    def test_load_missing_file_raises(self):
        with pytest.raises(ModelNotTrainedError):
            CharacterClassifier.load("/nonexistent/model.joblib", "/nonexistent/meta.joblib")
