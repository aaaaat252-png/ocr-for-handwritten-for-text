"""
tests/test_inference.py
=========================
End-to-end tests for inference/ocr_engine.py, exercising the trained
model against the generated sample images (real handwritten-digit
glyphs) and verifying accuracy, confidence scores, and error handling.

These tests assume `python scripts/train_model.py` and
`python examples/generate_sample_images.py` have already been run, and
will auto-run them (once, session-scoped) if the artifacts are missing
so the suite is runnable standalone via `pytest`.
"""

import os
import subprocess
import sys

import pytest

import config
from errors import OCRError
from inference.ocr_engine import OCREngine, recognize_text

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SAMPLES_DIR = os.path.join(PROJECT_ROOT, "examples", "sample_images")
GROUND_TRUTH_PATH = os.path.join(PROJECT_ROOT, "examples", "ground_truth.txt")


@pytest.fixture(scope="session", autouse=True)
def ensure_artifacts():
    """Make sure a trained model and sample images exist before running
    the inference test suite."""
    if not os.path.exists(config.MODEL_PATH):
        subprocess.run([sys.executable, os.path.join(PROJECT_ROOT, "scripts", "train_model.py")], check=True)
    if not os.path.exists(SAMPLES_DIR):
        subprocess.run([sys.executable, os.path.join(PROJECT_ROOT, "examples", "generate_sample_images.py")], check=True)
    yield


@pytest.fixture(scope="session")
def engine():
    return OCREngine()


@pytest.fixture(scope="session")
def ground_truth():
    gt = {}
    with open(GROUND_TRUTH_PATH) as f:
        for line in f:
            filename, text = line.strip().split("\t")
            gt[filename] = text
    return gt


class TestOCREngineRecognition:
    def test_single_digit_recognized(self, engine, ground_truth):
        filename = "sample_single_digit_7.png"
        result = engine.recognize(os.path.join(SAMPLES_DIR, filename))
        assert result.text.strip() == ground_truth[filename]

    def test_digit_sequence_recognized(self, engine, ground_truth):
        filename = "sample_sequence_12345.png"
        result = engine.recognize(os.path.join(SAMPLES_DIR, filename))
        assert result.text.strip() == ground_truth[filename]

    def test_all_sample_images_meet_accuracy_target(self, engine, ground_truth):
        """Aggregate character-level accuracy across every generated sample
        must meet the project's >90% target."""
        total_chars = 0
        correct_chars = 0
        for filename, expected in ground_truth.items():
            result = engine.recognize(os.path.join(SAMPLES_DIR, filename))
            predicted = result.text.strip()
            for i, ch in enumerate(expected):
                total_chars += 1
                if i < len(predicted) and predicted[i] == ch:
                    correct_chars += 1
        accuracy = correct_chars / total_chars
        assert accuracy >= config.TARGET_CHAR_ACCURACY, (
            f"Character accuracy {accuracy:.2%} fell below target "
            f"{config.TARGET_CHAR_ACCURACY:.0%}"
        )

    def test_confidence_scores_in_valid_range(self, engine):
        result = engine.recognize(os.path.join(SAMPLES_DIR, "sample_sequence_2024.png"))
        assert 0.0 <= result.mean_confidence <= 1.0
        for c in result.characters:
            assert 0.0 <= c.confidence <= 1.0

    def test_convenience_function(self, ground_truth):
        filename = "sample_sequence_2024.png"
        text = recognize_text(os.path.join(SAMPLES_DIR, filename))
        assert text.strip() == ground_truth[filename]

    def test_recognize_single_character_helper(self, engine):
        from preprocessing.pipeline import preprocess_image
        from inference.segmentation import segment_lines, segment_words, segment_characters

        binary = preprocess_image(os.path.join(SAMPLES_DIR, "sample_single_digit_7.png"))
        line = segment_lines(binary)[0]
        word = segment_words(line)[0]
        glyph, _box = segment_characters(word)[0]

        result = engine.recognize_single_character(glyph)
        assert result.char == "7"
        assert 0.0 <= result.confidence <= 1.0


class TestOCREngineErrorHandling:
    def test_nonexistent_image_raises(self, engine):
        with pytest.raises(OCRError):
            engine.recognize(os.path.join(SAMPLES_DIR, "does_not_exist.png"))

    def test_blank_page_raises(self, engine):
        with pytest.raises(OCRError):
            engine.recognize(os.path.join(SAMPLES_DIR, "blank_page.png"))

    def test_corrupt_file_raises(self, engine):
        with pytest.raises(OCRError):
            engine.recognize(os.path.join(SAMPLES_DIR, "corrupt_file.png"))

    def test_wrong_extension_raises(self, engine):
        with pytest.raises(OCRError):
            engine.recognize(os.path.join(SAMPLES_DIR, "not_an_image.txt"))

    def test_none_input_raises(self, engine):
        with pytest.raises(OCRError):
            engine.recognize(None)

    def test_engine_load_missing_model_raises(self):
        from errors import ModelNotTrainedError
        with pytest.raises(ModelNotTrainedError):
            OCREngine(model_path="/nonexistent/model.joblib", metadata_path="/nonexistent/meta.joblib")
