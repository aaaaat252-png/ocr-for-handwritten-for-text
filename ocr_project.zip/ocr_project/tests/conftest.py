"""
tests/conftest.py
===================
Ensures the project root is importable as a package root when running
`pytest` from anywhere, so `import config`, `import errors`, etc. work
without needing to install the project as a package.
"""

import os
import sys

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)
