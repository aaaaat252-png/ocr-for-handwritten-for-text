"""
config.py
=========
Single source of truth for paths, hyperparameters, and reproducibility
settings used across the OCR project. Every module imports from here
instead of hard-coding values, so the whole pipeline can be re-tuned
from one place.
"""

import os

# ---------------------------------------------------------------------------
# Reproducibility
# ---------------------------------------------------------------------------
RANDOM_SEED = 42

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
SAVED_MODELS_DIR = os.path.join(PROJECT_ROOT, "saved_models")
SAMPLE_OUTPUTS_DIR = os.path.join(PROJECT_ROOT, "sample_outputs")
EXAMPLES_DIR = os.path.join(PROJECT_ROOT, "examples")

MODEL_FILENAME = "character_classifier.joblib"
MODEL_METADATA_FILENAME = "model_metadata.joblib"
MODEL_PATH = os.path.join(SAVED_MODELS_DIR, MODEL_FILENAME)
MODEL_METADATA_PATH = os.path.join(SAVED_MODELS_DIR, MODEL_METADATA_FILENAME)

# ---------------------------------------------------------------------------
# Image / preprocessing parameters
# ---------------------------------------------------------------------------
# Size (height, width) that every isolated character glyph is normalized to
# before being fed to the classifier.
CHAR_IMAGE_SIZE = (28, 28)

# Otsu / adaptive thresholding behaviour
GAUSSIAN_BLUR_KERNEL = (3, 3)
ADAPTIVE_THRESH_BLOCK_SIZE = 25
ADAPTIVE_THRESH_C = 10

# Denoising strength for cv2.fastNlMeansDenoising
DENOISE_STRENGTH = 10

# Minimum contour area (in pixels) to be considered a real character stroke
# rather than noise/speckle when segmenting.
MIN_CHAR_CONTOUR_AREA = 8

# Minimum width/height (px) a bounding box must have to count as a character
MIN_CHAR_DIM = 3

# Gap (in pixels, relative to line height) used to decide where one word
# ends and the next begins during word segmentation.
WORD_GAP_RATIO = 1.4

# ---------------------------------------------------------------------------
# Model hyperparameters (scikit-learn MLPClassifier)
# ---------------------------------------------------------------------------
MLP_HIDDEN_LAYER_SIZES = (256, 128)
MLP_ACTIVATION = "relu"
MLP_ALPHA = 1e-4
MLP_MAX_ITER = 300
MLP_EARLY_STOPPING = True

# Fraction of data held out for validation during training
VALIDATION_SPLIT = 0.2

# Minimum acceptable character-level accuracy on the validation set.
# train.py will warn (not fail) if this is not met, since results depend
# on the dataset actually available at train time.
TARGET_CHAR_ACCURACY = 0.90
