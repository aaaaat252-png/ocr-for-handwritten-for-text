#!/usr/bin/env python3
"""
scripts/train_model.py
=======================
CLI entry point for training the character classifier.

Usage
-----
    python scripts/train_model.py
    python scripts/train_model.py --emnist-csv path/to/emnist-balanced-train.csv
"""

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.train import train_and_evaluate  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description="Train the OCR character classifier.")
    parser.add_argument(
        "--emnist-csv",
        type=str,
        default=None,
        help="Optional path to an EMNIST-format CSV for training on the full "
             "alphanumeric character set instead of the default digits dataset.",
    )
    args = parser.parse_args()

    metrics = train_and_evaluate(emnist_csv_path=args.emnist_csv)
    print("\n=== Training summary ===")
    print(f"Classes:            {metrics['n_classes']}")
    print(f"Train samples:      {metrics['n_train']}")
    print(f"Validation samples: {metrics['n_val']}")
    print(f"Char accuracy:      {metrics['char_accuracy'] * 100:.2f}%")
    print(f"Training time:      {metrics['training_seconds']:.1f}s")


if __name__ == "__main__":
    main()
