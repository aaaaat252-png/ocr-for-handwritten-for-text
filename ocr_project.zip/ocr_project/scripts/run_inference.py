#!/usr/bin/env python3
"""
scripts/run_inference.py
=========================
CLI entry point for running OCR on a single image.

Usage
-----
    python scripts/run_inference.py --image path/to/handwriting.png
    python scripts/run_inference.py --image path/to/handwriting.png --show-confidence
"""

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from errors import OCRError  # noqa: E402
from inference.ocr_engine import OCREngine  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description="Run handwritten OCR on an image.")
    parser.add_argument("--image", required=True, help="Path to the input image.")
    parser.add_argument(
        "--method", default="otsu", choices=["otsu", "adaptive"],
        help="Thresholding method to use during preprocessing.",
    )
    parser.add_argument(
        "--show-confidence", action="store_true",
        help="Print per-character confidence scores in addition to the text.",
    )
    args = parser.parse_args()

    try:
        engine = OCREngine()
        result = engine.recognize(args.image, method=args.method)
    except OCRError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    print("=== Recognized text ===")
    print(result.text)
    print()
    print(f"Mean confidence: {result.mean_confidence:.3f}")
    if result.warnings:
        print("Warnings:")
        for w in result.warnings:
            print(f"  - {w}")

    if args.show_confidence:
        print("\nPer-character confidence:")
        for c in result.characters:
            print(f"  '{c.char}': {c.confidence:.3f}")


if __name__ == "__main__":
    main()
