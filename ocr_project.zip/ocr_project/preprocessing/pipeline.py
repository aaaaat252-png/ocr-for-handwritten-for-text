"""
preprocessing/pipeline.py
==========================
Image preprocessing pipeline built on OpenCV. Responsible for turning an
arbitrary input image (file path, bytes, or numpy array) into a clean,
normalized, binary image ready for segmentation and classification.

Every public function validates its input and raises one of the custom
exceptions in `errors.py` with a descriptive message on failure, rather
than letting OpenCV fail silently (cv2 often returns None instead of
raising) or crash with an opaque stack trace.
"""

import os
from typing import Tuple

import cv2
import numpy as np

import config
from errors import EmptyImageError, InvalidImageError, UnsupportedFormatError

# Formats OpenCV can reliably decode for this project.
_SUPPORTED_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}


# ---------------------------------------------------------------------------
# Loading & validation
# ---------------------------------------------------------------------------
def load_image(path: str) -> np.ndarray:
    """
    Load an image from disk into a BGR numpy array.

    Raises
    ------
    InvalidImageError
        If `path` does not exist, is not a string, or points to a
        directory.
    UnsupportedFormatError
        If the file extension isn't supported or OpenCV fails to decode
        the file contents (corrupt file, wrong format, empty file, ...).
    """
    if not isinstance(path, str):
        raise InvalidImageError(
            f"Expected a file path (str), got {type(path).__name__}."
        )
    if not os.path.exists(path):
        raise InvalidImageError(f"Image path does not exist: '{path}'")
    if os.path.isdir(path):
        raise InvalidImageError(f"Expected a file, but got a directory: '{path}'")

    ext = os.path.splitext(path)[1].lower()
    if ext not in _SUPPORTED_EXTENSIONS:
        raise UnsupportedFormatError(
            f"Unsupported file extension '{ext}'. Supported formats: "
            f"{sorted(_SUPPORTED_EXTENSIONS)}"
        )

    if os.path.getsize(path) == 0:
        raise UnsupportedFormatError(f"File is empty (0 bytes): '{path}'")

    image = cv2.imread(path, cv2.IMREAD_COLOR)
    if image is None:
        # cv2.imread returns None on any decode failure instead of raising.
        raise UnsupportedFormatError(
            f"OpenCV could not decode '{path}'. The file may be corrupt "
            f"or is not a valid image despite its extension."
        )

    validate_image(image)
    return image


def validate_image(image: np.ndarray) -> None:
    """
    Validate that `image` is a usable, non-empty numpy array image.

    Raises
    ------
    InvalidImageError
        If `image` is None, not a numpy array, or has an invalid shape.
    EmptyImageError
        If the image has zero area or is a completely uniform (blank)
        canvas with no visual content at all.
    """
    if image is None:
        raise InvalidImageError("Image is None.")
    if not isinstance(image, np.ndarray):
        raise InvalidImageError(
            f"Expected a numpy.ndarray image, got {type(image).__name__}."
        )
    if image.size == 0:
        raise EmptyImageError("Image array is empty (zero elements).")
    if image.ndim not in (2, 3):
        raise InvalidImageError(
            f"Image must be 2D (grayscale) or 3D (color), got shape {image.shape}."
        )
    h, w = image.shape[:2]
    if h == 0 or w == 0:
        raise EmptyImageError(f"Image has a zero-length dimension: shape={image.shape}.")
    if h < 2 or w < 2:
        raise EmptyImageError(
            f"Image is too small to contain any content: shape={image.shape}."
        )


# ---------------------------------------------------------------------------
# Individual pipeline stages
# ---------------------------------------------------------------------------
def to_grayscale(image: np.ndarray) -> np.ndarray:
    """Convert a BGR or already-grayscale image to single-channel grayscale."""
    validate_image(image)
    if image.ndim == 2:
        return image.copy()
    if image.shape[2] == 4:
        return cv2.cvtColor(image, cv2.COLOR_BGRA2GRAY)
    return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)


def denoise(gray: np.ndarray) -> np.ndarray:
    """Reduce speckle/scanner noise while preserving stroke edges."""
    validate_image(gray)
    blurred = cv2.GaussianBlur(gray, config.GAUSSIAN_BLUR_KERNEL, 0)
    return cv2.fastNlMeansDenoising(blurred, h=config.DENOISE_STRENGTH)


def binarize(gray: np.ndarray, method: str = "otsu") -> np.ndarray:
    """
    Threshold a grayscale image to a binary image where text is white (255)
    on a black (0) background -- the convention the rest of the pipeline
    (segmentation, classifier) expects.

    Parameters
    ----------
    method : {"otsu", "adaptive"}
        "otsu" works well for evenly-lit scans; "adaptive" is more robust
        to uneven lighting/shadows across the page.
    """
    validate_image(gray)
    if method not in ("otsu", "adaptive"):
        raise InvalidImageError(f"Unknown binarization method: '{method}'")

    if method == "otsu":
        _, binary = cv2.threshold(
            gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU
        )
    else:
        binary = cv2.adaptiveThreshold(
            gray,
            255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY_INV,
            config.ADAPTIVE_THRESH_BLOCK_SIZE,
            config.ADAPTIVE_THRESH_C,
        )

    # Ensure text-is-white convention: if more than half the pixels are
    # "foreground", the polarity is probably inverted (e.g. dark page,
    # light ink) -- flip it back.
    if np.mean(binary) > 127:
        binary = cv2.bitwise_not(binary)
    return binary


def deskew(binary: np.ndarray) -> np.ndarray:
    """
    Correct small rotational skew using the minimum-area bounding rectangle
    of all foreground pixels. No-ops safely on blank images or images with
    negligible skew.
    """
    validate_image(binary)
    coords = np.column_stack(np.where(binary > 0))
    if coords.shape[0] < 10:
        # Not enough foreground pixels to reliably estimate an angle.
        return binary

    angle = cv2.minAreaRect(coords)[-1]
    if angle < -45:
        angle = -(90 + angle)
    else:
        angle = -angle

    # Skip correction for negligible or clearly-erroneous angle estimates.
    if abs(angle) < 0.5 or abs(angle) > 45:
        return binary

    (h, w) = binary.shape[:2]
    center = (w // 2, h // 2)
    matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
    rotated = cv2.warpAffine(
        binary, matrix, (w, h), flags=cv2.INTER_NEAREST, borderMode=cv2.BORDER_CONSTANT
    )
    return rotated


def normalize_glyph(binary_glyph: np.ndarray, target_size: Tuple[int, int] = None) -> np.ndarray:
    """
    Resize a single cropped character glyph to `target_size`
    (height, width), preserving aspect ratio via padding, and scale pixel
    values to [0, 1] float32. This is the final step before flattening
    for the classifier.
    """
    validate_image(binary_glyph)
    target_size = target_size or config.CHAR_IMAGE_SIZE
    target_h, target_w = target_size

    h, w = binary_glyph.shape[:2]
    scale = min((target_h - 4) / h, (target_w - 4) / w)
    scale = max(scale, 1e-6)
    new_h, new_w = max(1, int(h * scale)), max(1, int(w * scale))
    resized = cv2.resize(binary_glyph, (new_w, new_h), interpolation=cv2.INTER_AREA)

    canvas = np.zeros((target_h, target_w), dtype=np.uint8)
    y_off = (target_h - new_h) // 2
    x_off = (target_w - new_w) // 2
    canvas[y_off:y_off + new_h, x_off:x_off + new_w] = resized

    return (canvas.astype(np.float32)) / 255.0


# ---------------------------------------------------------------------------
# Full pipeline
# ---------------------------------------------------------------------------
def preprocess_image(image_input, method: str = "otsu", apply_deskew: bool = True) -> np.ndarray:
    """
    Run the full preprocessing pipeline: load (if a path) -> grayscale ->
    denoise -> binarize -> deskew.

    Parameters
    ----------
    image_input : str or np.ndarray
        Either a file path or an already-loaded BGR/grayscale numpy array.

    Returns
    -------
    np.ndarray
        A cleaned binary (uint8, values in {0, 255}) image with text as
        white foreground on a black background.
    """
    if isinstance(image_input, str):
        image = load_image(image_input)
    else:
        validate_image(image_input)
        image = image_input

    gray = to_grayscale(image)
    denoised = denoise(gray)
    binary = binarize(denoised, method=method)

    if np.count_nonzero(binary) == 0:
        raise EmptyImageError(
            "Image contains no detectable foreground content after "
            "thresholding (page appears blank)."
        )

    if apply_deskew:
        binary = deskew(binary)

    return binary
