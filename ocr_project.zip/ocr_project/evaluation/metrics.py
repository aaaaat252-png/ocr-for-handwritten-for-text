"""
evaluation/metrics.py
======================
Metrics for evaluating OCR quality: character-level accuracy, word-level
accuracy, Levenshtein-based character error rate, and confidence-score
summaries.
"""

from typing import Dict, List, Sequence

import numpy as np
from sklearn.metrics import classification_report


def character_accuracy(y_true: Sequence, y_pred: Sequence) -> float:
    """Fraction of individually-classified characters that are correct."""
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    if len(y_true) == 0:
        return 0.0
    if len(y_true) != len(y_pred):
        raise ValueError(
            f"y_true and y_pred must be the same length, got {len(y_true)} and {len(y_pred)}."
        )
    return float(np.mean(y_true == y_pred))


def word_accuracy(true_words: List[str], pred_words: List[str]) -> float:
    """Fraction of whole words transcribed with zero character errors."""
    if len(true_words) == 0:
        return 0.0
    if len(true_words) != len(pred_words):
        raise ValueError("true_words and pred_words must be the same length.")
    correct = sum(1 for t, p in zip(true_words, pred_words) if t == p)
    return correct / len(true_words)


def levenshtein_distance(a: str, b: str) -> int:
    """Classic edit distance, used for character error rate (CER)."""
    if a == b:
        return 0
    if len(a) == 0:
        return len(b)
    if len(b) == 0:
        return len(a)

    prev_row = list(range(len(b) + 1))
    for i, ca in enumerate(a, start=1):
        cur_row = [i] + [0] * len(b)
        for j, cb in enumerate(b, start=1):
            cost = 0 if ca == cb else 1
            cur_row[j] = min(
                prev_row[j] + 1,       # deletion
                cur_row[j - 1] + 1,    # insertion
                prev_row[j - 1] + cost # substitution
            )
        prev_row = cur_row
    return prev_row[-1]


def character_error_rate(true_text: str, pred_text: str) -> float:
    """Levenshtein distance normalized by reference length (CER). Lower is better."""
    if len(true_text) == 0:
        return 0.0 if len(pred_text) == 0 else 1.0
    return levenshtein_distance(true_text, pred_text) / len(true_text)


def confidence_stats(confidences: Sequence[float]) -> Dict[str, float]:
    """Summary statistics for a batch of per-character confidence scores."""
    if len(confidences) == 0:
        return {"mean": 0.0, "min": 0.0, "max": 0.0, "std": 0.0}
    arr = np.asarray(confidences, dtype=np.float64)
    return {
        "mean": float(np.mean(arr)),
        "min": float(np.min(arr)),
        "max": float(np.max(arr)),
        "std": float(np.std(arr)),
    }


def classification_report_dict(y_true, y_pred, label_map: Dict[int, str] = None) -> dict:
    """Per-class precision/recall/F1 report as a plain dict (JSON-friendly)."""
    target_names = None
    if label_map:
        classes = sorted(set(np.asarray(y_true).tolist()) | set(np.asarray(y_pred).tolist()))
        target_names = [label_map.get(c, str(c)) for c in classes]
    return classification_report(
        y_true, y_pred, target_names=target_names, output_dict=True, zero_division=0
    )
