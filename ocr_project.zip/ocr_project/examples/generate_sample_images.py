#!/usr/bin/env python3
"""
examples/generate_sample_images.py
====================================
Builds sample test images from real handwritten digit glyphs (from the
sklearn digits dataset) so the OCR pipeline can be demonstrated and
tested end-to-end without needing external scanned images.

Also generates a few deliberately invalid/corrupt files so the error
handling paths have concrete fixtures to test against.

Output goes to examples/sample_images/ with a matching
examples/ground_truth.txt listing the expected transcription for each
generated image.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import cv2
import numpy as np
from sklearn.datasets import load_digits

import config

OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample_images")


def _glyph_to_canvas(glyph_8x8: np.ndarray, size: int = 48) -> np.ndarray:
    """Upscale an 8x8 sklearn digit glyph (0-16 range) to a clean, ink-only
    (cropped-to-content) uint8 image with ink=dark on a white background,
    matching what a real scanned handwriting sample looks like."""
    img = (glyph_8x8 / 16.0 * 255).astype(np.uint8)
    img = cv2.resize(img, (size, size), interpolation=cv2.INTER_CUBIC)
    img = 255 - img  # sklearn glyphs are ink=bright; flip to ink=dark on white
    _, img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    # Crop tightly to the ink so glyphs can be packed close together like
    # letters within a real handwritten word, rather than leaving each
    # glyph's original padding (which would read as inter-word gaps).
    ink_mask = img < 127
    ys, xs = np.where(ink_mask)
    if len(xs) == 0:
        return img
    pad = 2
    y0, y1 = max(0, ys.min() - pad), min(img.shape[0], ys.max() + pad + 1)
    x0, x1 = max(0, xs.min() - pad), min(img.shape[1], xs.max() + pad + 1)
    return img[y0:y1, x0:x1]


def build_sequence_image(digit_images, digit_labels, target_labels, rng, spacing=6, margin=20):
    """Compose several real handwritten-digit glyphs into a single-line,
    single-word image, simulating a handwritten number sequence. Glyphs are
    vertically centered on a common baseline before being placed."""
    glyphs = []
    for label in target_labels:
        candidates = np.where(digit_labels == label)[0]
        idx = rng.choice(candidates)
        glyphs.append(_glyph_to_canvas(digit_images[idx], size=48))

    h = max(g.shape[0] for g in glyphs)
    total_w = sum(g.shape[1] for g in glyphs) + spacing * (len(glyphs) - 1) + margin * 2
    total_h = h + margin * 2

    canvas = np.full((total_h, total_w), 255, dtype=np.uint8)
    x = margin
    for g in glyphs:
        gh, gw = g.shape
        y_off = margin + (h - gh) // 2
        canvas[y_off:y_off + gh, x:x + gw] = g
        x += gw + spacing

    canvas_bgr = cv2.cvtColor(canvas, cv2.COLOR_GRAY2BGR)
    return canvas_bgr


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    rng = np.random.default_rng(config.RANDOM_SEED)

    digits = load_digits()
    digit_images, digit_labels = digits.images, digits.target

    samples = {
        "sample_single_digit_7.png": [7],
        "sample_sequence_12345.png": [1, 2, 3, 4, 5],
        "sample_sequence_90210.png": [9, 0, 2, 1, 0],
        "sample_sequence_2024.png": [2, 0, 2, 4],
    }

    ground_truth_lines = []
    for filename, labels in samples.items():
        img = build_sequence_image(digit_images, digit_labels, labels, rng)
        path = os.path.join(OUT_DIR, filename)
        cv2.imwrite(path, img)
        ground_truth_lines.append(f"{filename}\t{''.join(str(d) for d in labels)}")
        print(f"Wrote {path}  (ground truth: {''.join(str(d) for d in labels)})")

    # -- Fixtures for error-handling tests / demonstration --------------
    blank_path = os.path.join(OUT_DIR, "blank_page.png")
    cv2.imwrite(blank_path, np.full((200, 400), 255, dtype=np.uint8))
    print(f"Wrote {blank_path} (blank page, expected to raise EmptyImageError)")

    corrupt_path = os.path.join(OUT_DIR, "corrupt_file.png")
    with open(corrupt_path, "wb") as f:
        f.write(b"this is not a valid png file, just some bytes")
    print(f"Wrote {corrupt_path} (corrupt file, expected to raise UnsupportedFormatError)")

    not_image_path = os.path.join(OUT_DIR, "not_an_image.txt")
    with open(not_image_path, "w") as f:
        f.write("plain text file, wrong extension test")
    print(f"Wrote {not_image_path} (wrong extension, expected to raise UnsupportedFormatError)")

    gt_path = os.path.join(os.path.dirname(OUT_DIR), "ground_truth.txt")
    with open(gt_path, "w") as f:
        f.write("\n".join(ground_truth_lines) + "\n")
    print(f"Wrote ground truth to {gt_path}")


if __name__ == "__main__":
    main()
